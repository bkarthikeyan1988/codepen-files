$( ".menuItem" ).click(function() {
    $( ".menuItem" ).removeClass('selected');
    $( this ).addClass('selected');
});